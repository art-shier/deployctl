# notes v1.0.0

Install using deployctl and the external SHA256 checksum.
Keep production config outside this archive. No database migration is performed.
