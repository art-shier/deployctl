# Managed multi-service release
Install using ctl with multi_service_v1 support.
